#ifndef CPP_ADVANCED_ECHO_H
#define CPP_ADVANCED_ECHO_H

#include <iostream>

extern bool echoOn;

void echo(const std::string& message);

#endif //CPP_ADVANCED_ECHO_H
