﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlitchesTestGenerator.RandomExtensions;
namespace GlitchesTestGenerator
{
    class Program
    {
        static Random random = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, new List<int>() { 3 });
            GenerateTest("test.002", 20, new List<int>() { 8 });
            GenerateTest("test.003", 30, new List<int>() { 1 });
            GenerateTest("test.004", 40, new List<int>() { 7 });
            GenerateTest("test.005", 50, new List<int>() { 20 });

            GenerateTest("test.006", 60, new List<int>() { 4, 5, 10, 3 });
            GenerateTest("test.007", 70, new List<int>() { 1, 1, 1, 1, 1, 1 });
            GenerateTest("test.008", 80, new List<int>() { 8, 3, 1, 9, 10, 3, 3, 3, 2, 1 });
            GenerateTest("test.009", 90, new List<int>() { 1, 1, 1, 9, 10, 1, 2, 1, 2, 1 });
            GenerateTest("test.010", 100, new List<int>() { 10, 10, 30, 5, 1, 3, 2, 8, 1 });
        }

        private static void GenerateTest(string name, int matrixSize, List<int> radii)
        {
            string symbolsStr = "!?@#$%^&*()_+-=[]{}|:";
            List<char> symbolsList = symbolsStr.ToList();
            random.NextShuffle(symbolsList);

            HashSet<char> symbols = new HashSet<char>(symbolsList);

            char[,] matrix = GetMatrix(matrixSize);
            char[,] resultMatrix = GetMatrix(matrixSize);

            foreach (var radius in radii)
            {
                int row = 0;
                int col = 0;
                while (!CanPlaceGlitch(matrix, row, col, radius))
                {
                    row = random.Next(1 + radius, matrixSize - radius);
                    col = random.Next(1 + radius, matrixSize - radius);
                }

                char symbol = symbols.First();

                PlaceGlitch(matrix, row, col, radius, symbol);
                resultMatrix[row, col] = symbol;

                symbols.Remove(symbol);
            }

            System.IO.File.WriteAllLines(name + ".in.txt", new List<string>() { matrixSize + "", GetMatrixString(matrix) });
            System.IO.File.WriteAllLines(name + ".out.txt", new List<string>() { GetMatrixString(resultMatrix) });
        }

        private static string GetMatrixString(char[,] matrix)
        {
            StringBuilder s = new StringBuilder();
            for (int r = 0; r < matrix.GetLength(0); r++)
            {
                for (int c = 0; c < matrix.GetLength(1); c++)
                {
                    s.Append(matrix[r, c]);
                }
                s.AppendLine();
            }

            return s.ToString();
        }

        private static char[,] GetMatrix(int size)
        {
            char[,] matrix = new char[size, size];

            for (int row = 0; row < size; row++)
            {
                for (int col = 0; col < size; col++)
                {
                    matrix[row, col] = '.';
                }
            }

            return matrix;
        }

        private static bool PlaceGlitch(char[,] matrix, int row, int col, int radius, char symbol)
        {
            int firstRow = row - radius;
            int lastRow = row + radius;
            int rightCol = col + radius;
            int leftCol = col - radius;

            for (int r = firstRow; r <= lastRow; r++)
            {
                for (int c = leftCol; c <= rightCol; c++)
                {
                    int dist = Math.Abs(r - row) + Math.Abs(c - col);
                    if (dist <= radius)
                    {
                        matrix[r, c] = symbol;
                    }
                }
            }

            return true;
        }

        private static bool CanPlaceGlitch(char[,] matrix, int row, int col, int radius)
        {
            int firstRow = row - radius;
            int lastRow = row + radius;
            int rightCol = col + radius;
            int leftCol = col - radius;

            if (firstRow <= 0 || lastRow >= matrix.GetLength(0) - 1 ||
                leftCol <= 0 || rightCol >= matrix.GetLength(1) - 1)
            {
                return false;
            }

            for (int r = firstRow - 1; r <= lastRow + 1; r++)
            {
                for (int c = leftCol - 1; c <= rightCol + 1; c++)
                {
                    int dist = Math.Abs(r - row) + Math.Abs(c - col);
                    if (dist <= radius + 1 && matrix[r, c] != '.')
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }

    namespace RandomExtensions
    {
        struct Pair<T>
        {
            public T First { get; set; }
            public T Second { get; set; }
            public Pair(T first, T second)
            {
                this.First = first;
                this.Second = second;
            }
        }

        static class RandomExtensions
        {
            public static List<int> NextIncreasingOrEqualInRange(this Random r, int length, Pair<int> rangeInclusive)
            {
                List<int> values = new List<int>();
                while (values.Count < length)
                {
                    values.Add(r.Next(values.Count > 0 ? values[values.Count - 1] : rangeInclusive.First, rangeInclusive.Second + 1));
                }

                return new List<int>(values);
            }

            public static List<int> NextStrictlyIncreasingInRange(this Random r, int length, Pair<int> rangeInclusive)
            {
                int rangeElementsCount = (rangeInclusive.Second - rangeInclusive.First) + 1;
                if (rangeElementsCount < length)
                {
                    throw new ArgumentException("rangeInclusive does not contain enough values to generate required length");
                }

                SortedSet<int> values = new SortedSet<int>();
                while (values.Count < length)
                {
                    values.Add(r.Next(rangeInclusive.First, rangeInclusive.Second + 1));
                }

                return new List<int>(values);
            }

            public static void NextShuffle<T>(this Random r, List<T> list)
            {
                for (int repeats = 0; repeats < 10; repeats++)
                {
                    for (int i = 0; i < list.Count; i++)
                    {
                        int otherInd = r.Next(0, list.Count);
                        var swap = list[i];
                        list[i] = list[otherInd];
                        list[otherInd] = swap;
                    }
                }
            }

            public static int NextIndex<T>(this Random r, ICollection<T> range)
            {
                return r.Next(0, range.Count);
            }

            public static T NextFrom<T>(this Random r, List<T> from)
            {
                return from[NextIndex(r, from)];
            }

            public static List<int> NextIntegersFrom(this Random r, int count, List<int> from)
            {
                List<int> integers = new List<int>();

                while (integers.Count < count)
                {
                    integers.Add(NextFrom(r, from));
                }

                return integers;
            }

            public static List<int> NextIntegers(this Random r, int count)
            {
                return NextIntegersExcluding(r, count, new HashSet<int>());
            }

            public static List<int> NextIntegersExcluding(this Random r, int count, HashSet<int> excluded)
            {
                List<int> integers = new List<int>();

                while (integers.Count < count)
                {
                    integers.Add(NextExcluding(r, excluded));
                }

                return integers;
            }

            public static int NextExcluding(this Random r, HashSet<int> excluded)
            {
                int value = r.Next();
                while (excluded.Contains(value))
                {
                    value = r.Next();
                }

                return value;
            }
        }
    }
}
