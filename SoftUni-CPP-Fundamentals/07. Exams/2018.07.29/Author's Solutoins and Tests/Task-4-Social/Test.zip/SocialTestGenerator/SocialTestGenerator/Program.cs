﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RandomExtensions;

namespace SocialTestGenerator
{
    class Program
    {
        class UserPair : Pair<string>
        {
            public string UserA
            {
                get
                {
                    return this.First;
                }
            }

            public string UserB
            {
                get
                {
                    return this.Second;
                }
            }

            public UserPair(string userA, string userB) : base(userA, userB)
            {
            }

            public override bool Equals(object obj)
            {
                if (obj == null)
                {
                    return false;
                }

                UserPair other = (UserPair)obj;
                return (this.First == other.First && this.Second == other.Second) || (this.Second == other.First && this.First == other.Second);
            }

            public override int GetHashCode()
            {
                return this.First.GetHashCode() + this.Second.GetHashCode();
            }
        }

        class Group
        {
            public HashSet<string> Users { get; private set; } = new HashSet<string>();
            Dictionary<string, HashSet<string>> usersByProfession = new Dictionary<string, HashSet<string>>();
            Dictionary<string, string> userProfessions = new Dictionary<string, string>();
            Dictionary<string, HashSet<string>> friendsByUser = new Dictionary<string, HashSet<string>>();
            public HashSet<UserPair> Friendships { get; private set; } = new HashSet<UserPair>();

            public SortedSet<string> GetNonFriendColleagues(string user)
            {
                string profession = userProfessions[user];

                HashSet<string> friends = friendsByUser[user];
                SortedSet<string> colleagues = new SortedSet<string>();
                foreach (var professionUser in usersByProfession[profession])
                {
                    if (professionUser != user && !friends.Contains(professionUser))
                    {
                        colleagues.Add(professionUser);
                    }
                }

                return colleagues;
            }

            public Group AddUser(string user, string profession)
            {
                if (Users.Contains(user))
                {
                    throw new ArgumentException(user + " is already a member of this group");
                }

                Users.Add(user);

                if (!usersByProfession.ContainsKey(profession))
                {
                    usersByProfession.Add(profession, new HashSet<string>());
                }

                usersByProfession[profession].Add(user);
                userProfessions.Add(user, profession);

                return this;
            }

            public Group AddFriendship(string userA, string userB)
            {
                if (userA == userB)
                {
                    throw new ArgumentException(userA + " can't be a friend of themselves");
                }

                if (!Users.Contains(userA) || !Users.Contains(userB))
                {
                    throw new ArgumentException("Both users must be members of this group");
                }

                if (AddFriend(userA, userB) && AddFriend(userB, userA))
                {
                    Friendships.Add(new UserPair(userA, userB));
                }

                return this;
            }

            private bool AddFriend(string userA, string userB)
            {
                if (!this.friendsByUser.ContainsKey(userA))
                {
                    this.friendsByUser.Add(userA, new HashSet<string>());
                }

                return friendsByUser[userA].Add(userB);
            }

            public string GetProfession(string u)
            {
                return userProfessions[u];
            }
        }

        static Random rand = new Random();
        const int MaxWordLength = 8;

        static void Main(string[] args)
        {

            GenerateTest(testName: "test.001", groupsCount: 2, usersPerGroup: 4, minFriendshipsPerGroupCount: 3, professionsCount: 5, suggestionsCount: 3);
            GenerateTest(testName: "test.002", groupsCount: 10, usersPerGroup: 2, minFriendshipsPerGroupCount: 1, professionsCount: 2, suggestionsCount: 5);
            GenerateTest(testName: "test.003", groupsCount: 10, usersPerGroup: 8, minFriendshipsPerGroupCount: 10, professionsCount: 50, suggestionsCount: 1);
            GenerateTest(testName: "test.004", groupsCount: 10, usersPerGroup: 8, minFriendshipsPerGroupCount: 12, professionsCount: 8, suggestionsCount: 10);
            GenerateTest(testName: "test.005", groupsCount: 2, usersPerGroup: 40, minFriendshipsPerGroupCount: 50, professionsCount: 15, suggestionsCount: 10);

            GenerateTest(testName: "test.006", groupsCount: 2, usersPerGroup: 400, minFriendshipsPerGroupCount: 600, professionsCount: 25, suggestionsCount: 30);
            GenerateTest(testName: "test.007", groupsCount: 300, usersPerGroup: 3, minFriendshipsPerGroupCount: 2, professionsCount: 25, suggestionsCount: 50);
            GenerateTest(testName: "test.008", groupsCount: 10, usersPerGroup: 60, minFriendshipsPerGroupCount: 80, professionsCount: 50, suggestionsCount: 80);
            GenerateTest(testName: "test.009", groupsCount: 30, usersPerGroup: 10, minFriendshipsPerGroupCount: 33, professionsCount: 25, suggestionsCount: 100);
            GenerateTest(testName: "test.010", groupsCount: 25, usersPerGroup: 40, minFriendshipsPerGroupCount: 39, professionsCount: 50, suggestionsCount: 100);
        }

        static void GenerateTest(string testName, int groupsCount, int usersPerGroup, int minFriendshipsPerGroupCount, int professionsCount, int suggestionsCount)
        {
            List<string> allProfessions = new List<string>(rand.NextUniqueN(professionsCount, () => rand.NextWord(rand.Next(1, MaxWordLength))));

            HashSet<string> allUsers = new HashSet<string>();

            List<Group> groups = new List<Group>();
            while (groups.Count < groupsCount)
            {
                Group g = new Group();
                List<string> groupUsers = new List<string>();

                for (int i = 0; i < usersPerGroup; i++)
                {
                    string user = rand.NextWord(rand.Next(1, MaxWordLength));
                    while (allUsers.Contains(user))
                    {
                        user = rand.NextWord(rand.Next(1, MaxWordLength));
                    }
                    allUsers.Add(user);
                    groupUsers.Add(user);

                    g.AddUser(user, rand.NextFrom(allProfessions));

                    if (groupUsers.Count > 1)
                    {
                        string friend = rand.NextFrom(groupUsers);
                        while (friend == user)
                        {
                            friend = rand.NextFrom(groupUsers);
                        }
                        g.AddFriendship(user, friend);
                    }
                }

                while (g.Friendships.Count < minFriendshipsPerGroupCount)
                {
                    string userA = rand.NextFrom(groupUsers);
                    string userB = rand.NextFrom(groupUsers);
                    while (userB == userA)
                    {
                        userB = rand.NextFrom(groupUsers);
                    }
                    g.AddFriendship(userA, userB);
                }

                groups.Add(g);
            }

            List<string> suggestionsInput = new List<string>();
            List<SortedSet<string>> suggestedUsers = new List<SortedSet<string>>();
            while (suggestionsInput.Count < suggestionsCount)
            {
                Group g = rand.NextFrom(groups);
                string user = rand.NextFrom(new List<string>(g.Users));

                suggestionsInput.Add(user);
                SortedSet<string> suggestion = g.GetNonFriendColleagues(user);
                foreach (var u in suggestion)
                {
                    if (g.GetProfession(u) != g.GetProfession(user))
                    {
                        throw new Exception("Expected professions to match that of search user");
                    }
                }
                suggestedUsers.Add(suggestion);
            }

            List<string> usersLines = groups.SelectMany(g =>
            {
                List<string> groupUsersAndProfessions = new List<string>();
                foreach (var u in g.Users)
                {
                    groupUsersAndProfessions.Add(u + " " + g.GetProfession(u));
                }

                return groupUsersAndProfessions;
            }).ToList();
            rand.NextShuffle(usersLines);

            List<string> friendshipsLines = groups.SelectMany(g => g.Friendships.Select(f => f.First + " " + f.Second)).ToList();
            rand.NextShuffle(friendshipsLines);

            List<string> inputLines = new List<string>();
            inputLines.AddRange(usersLines);
            inputLines.Add("---");
            inputLines.AddRange(friendshipsLines);
            inputLines.Add("---");
            inputLines.AddRange(suggestionsInput);
            inputLines.Add("---");

            List<string> outputLines = suggestedUsers.Select(set =>
            {
                if (set.Count > 0)
                {
                    return string.Join(" ", set);

                }
                else
                {
                    return "-";
                }
            }).ToList();

            System.IO.File.WriteAllLines(testName + ".in.txt", inputLines);
            System.IO.File.WriteAllLines(testName + ".out.txt", outputLines);
        }
    }
}

namespace RandomExtensions
{
    class Pair<T>
    {
        public T First { get; set; }
        public T Second { get; set; }
        public Pair(T first, T second)
        {
            this.First = first;
            this.Second = second;
        }
    }

    static class RandomExtensions
    {
        const string Vowels = "aeiouwy";
        const string Consonants = "bcdfghjklmnpqrstvwxz";

        public static HashSet<T> NextUniqueN<T>(this Random r, int count, Func<T> generator)
        {
            HashSet<T> unique = new HashSet<T>();

            while (unique.Count < count)
            {
                unique.Add(generator.Invoke());
            }

            return unique;
        }

        public static string NextWord(this Random r, int length, double capitalsChance = 0)
        {
            StringBuilder word = new StringBuilder();

            while (word.Length < length)
            {
                string source;
                if (word.Length == 0)
                {
                    source = r.NextChance(0.5) ? Vowels : Consonants;
                }
                else if (Vowels.Contains(word[word.Length - 1]))
                {
                    source = r.NextChance(0.8) ? Consonants : Vowels;
                }
                else
                {
                    source = r.NextChance(0.8) ? Vowels : Consonants;
                }

                word.Append(source[r.Next(0, source.Length)]);
            }

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = r.NextChance(capitalsChance) ? char.ToUpper(word[i]) : word[i];
            }

            return word.ToString();
        }

        public static bool NextChance(this Random r, double probability)
        {
            // NOTE: 0 probability is always false (min NextDouble() is 0, 0 < 0 is false) and 1 probability is always true (NextDouble() always returns less than 1)
            return r.NextDouble() < probability;
        }

        public static List<int> NextIncreasingOrEqualInRange(this Random r, int length, Pair<int> rangeInclusive)
        {
            List<int> values = new List<int>();
            while (values.Count < length)
            {
                values.Add(r.Next(values.Count > 0 ? values[values.Count - 1] : rangeInclusive.First, rangeInclusive.Second + 1));
            }

            return new List<int>(values);
        }

        public static List<int> NextStrictlyIncreasingInRange(this Random r, int length, Pair<int> rangeInclusive)
        {
            int rangeElementsCount = (rangeInclusive.Second - rangeInclusive.First) + 1;
            if (rangeElementsCount < length)
            {
                throw new ArgumentException("rangeInclusive does not contain enough values to generate required length");
            }

            SortedSet<int> values = new SortedSet<int>();
            while (values.Count < length)
            {
                values.Add(r.Next(rangeInclusive.First, rangeInclusive.Second + 1));
            }

            return new List<int>(values);
        }

        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextFrom<T>(this Random r, List<T> from)
        {
            return from[NextIndex(r, from)];
        }

        public static List<int> NextIntegersFrom(this Random r, int count, List<int> from)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextFrom(r, from));
            }

            return integers;
        }

        public static List<int> NextIntegers(this Random r, int count)
        {
            return NextIntegersExcluding(r, count, new HashSet<int>());
        }

        public static List<int> NextIntegersExcluding(this Random r, int count, HashSet<int> excluded)
        {
            List<int> integers = new List<int>();

            while (integers.Count < count)
            {
                integers.Add(NextExcluding(r, excluded));
            }

            return integers;
        }

        public static int NextExcluding(this Random r, HashSet<int> excluded)
        {
            int value = r.Next();
            while (excluded.Contains(value))
            {
                value = r.Next();
            }

            return value;
        }
    }
}
