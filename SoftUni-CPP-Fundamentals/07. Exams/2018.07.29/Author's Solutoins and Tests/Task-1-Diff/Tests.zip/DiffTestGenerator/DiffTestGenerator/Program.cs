﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiffTestGenerator
{
    class Program
    {
        static Random r = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", "She-sells-sea-shells-on-the-sea-shore", new Pair('a', 'b'), new Pair('C', 'd'), new Pair('Q', 'r'));
            GenerateTest("test.002", "She.?s?el--ls-sea-sh+__+-ells-on-the,sea,,-,shore", new Pair('&', '$'), new Pair('A', 'a'));
            GenerateTest("test.003", "S-h-e---s-e-l-l-s--s-e-a---s-h-e-l-l-s--o-n---t-h-e---se-a---s-h-o-r-e-", new Pair('1', '2'));
            GenerateTest("test.004", "Roses-are-red,-violets-are-blue,-unexpected-'{'-on-line-32", new Pair('a', 'b'), new Pair('C', 'd'), new Pair('Z', 'w'), new Pair('w', 'Z'), new Pair('1', '0'), new Pair('Y', 'x'), new Pair('x', 'L'), new Pair('5', '6'), new Pair('%', '#'), new Pair('a', 'b'), new Pair('C', 'd'), new Pair('Q', 'r'));
            GenerateTest("test.005", "'$?^^#?$$^_)&*()#)()+?_)?$$$?_*#%)?%T#^+)||}{{}@#%}?@{%?@%|", new Pair('a', 'A'), new Pair('h', 'H'), new Pair('g', 'G'), new Pair('#', 'I'));

            GenerateTest("test.006", "abcdefghijklmnopqrstuvwxyz", new Pair('a', 'A'), new Pair('2', 'R'), new Pair('j', 'K'));
            GenerateTest("test.007", "?#^%)*&@)*^?)^-the-quick-brown-fox-jumps-over-the-lazy-dog", new Pair('a', 'A'), new Pair('2', 'R'), new Pair('j', 'K'), new Pair('a', 'A'), new Pair('2', 'R'), new Pair('j', 'K'), new Pair('a', 'A'), new Pair('2', 'R'), new Pair('j', 'K'), new Pair('a', 'A'), new Pair('2', 'R'), new Pair('j', 'K'));
            GenerateTest("test.008", "Be-sure-to-get-what-you-like,-or-else-you'll-be-forced-to-like-what-you-get", new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['));
            GenerateTest("test.009", "You-can-hack-some-of-the-tests-some-of-the-time,-or-one-of-the-tests-all-of-the-time,-but-you-can't-fool-all-of-the-tests-all-of-the-time");
            GenerateTest("test.010", "There-are-old-pilots-and-there-are-bold-pilots,-but-there-are-no-old-bold-pilots", new Pair('a', 'b'), new Pair('C', 'd'), new Pair('Z', 'w'), new Pair('w', 'Z'), new Pair('1', '0'), new Pair('Y', 'x'), new Pair('x', 'L'), new Pair('5', '6'), new Pair('%', '#'), new Pair('a', 'b'), new Pair('C', 'd'), new Pair('Q', 'r'), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['), new Pair('-', '_'), new Pair('[', '{'), new Pair('{', '['));
        }

        struct Pair
        {
            public char First { get; set; }
            public char Second { get; set; }
            public Pair(char first, char second)
            {
                this.First = first;
                this.Second = second;
            }
        }

        private static void GenerateTest(string testName, string text, params Pair[] changes)
        {
            StringBuilder firstLine = new StringBuilder(text);
            StringBuilder secondLine = new StringBuilder(text);
            StringBuilder diffLine = new StringBuilder(text);
            List<int> diffIndices = new List<int>();
            foreach (var change in changes)
            {
                int index = r.Next(0, text.Length);
                while (diffLine[index] == '!')
                {
                    index = r.Next(0, text.Length);
                }

                firstLine[index] = change.First;
                secondLine[index] = change.Second;

                if (char.ToUpper(change.First) != char.ToUpper(change.Second))
                {
                    diffIndices.Add(index);
                    diffLine[index] = '!';
                }
                else if (change.First != change.Second)
                {
                    diffLine[index] = char.ToUpper(change.First);
                }
            }
            diffIndices.Sort();

            System.IO.File.WriteAllText(testName + ".in.txt", firstLine.Length + System.Environment.NewLine + firstLine.ToString() + System.Environment.NewLine + secondLine.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", diffLine.ToString() + System.Environment.NewLine + diffIndices.Count);
        }
    }

    static class RandomExtensions
    {
        public static void NextShuffle<T>(this Random r, List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = r.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }

        public static int NextIndex<T>(this Random r, ICollection<T> range)
        {
            return r.Next(0, range.Count);
        }

        public static T NextItem<T>(this Random r, IList<T> range)
        {
            return range[r.Next(0, range.Count)];
        }

        public static string NextWord(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1));
            }

            return new string(word);
        }

        public static string NextText(this Random r, int length)
        {
            char[] text = new char[length];
            for (int i = 0; i < text.Length; i++)
            {
                text[i] = i < length - 1 && i != 0 && char.IsLetter(text[i - 1]) && NextChance(r, 0.1) ?
                    ' ' : (char)r.Next('a', 'z' + 1);
            }

            return string.Join("", text);
        }

        public static string NextWordOrNumber(this Random r, int length)
        {
            char[] word = new char[length];

            for (int i = 0; i < word.Length; i++)
            {
                word[i] = (char)(r.Next() % 2 == 0 ?
                    (r.Next() % 2 == 0 ? r.Next('A', 'Z' + 1) : r.Next('a', 'z' + 1))
                    : (r.Next('0', '9' + 1)));
            }

            return new string(word);
        }

        public static string NextReplaceN(this Random r, string s, char replaceChar, int count)
        {
            StringBuilder result = new StringBuilder(s);

            for (int i = 0; i < count; i++)
            {
                result[r.Next(0, s.Length)] = replaceChar;
            }

            return result.ToString();
        }

        public static List<double> NextUniqueDoubles(this Random r, int count, double min = -double.MaxValue / 2, double max = double.MaxValue / 2, int digitsAfterPoint = 2)
        {
            HashSet<double> unique = new HashSet<double>();

            double range = max - min;
            while (unique.Count < count)
            {
                double number = double.Parse((min + range * r.NextDouble()).ToString("#." + new string('#', digitsAfterPoint)));
                unique.Add(number);
            }

            return unique.ToList();
        }

        public static bool NextChance(this Random r, double odds0To1)
        {
            return r.NextDouble() < odds0To1;
        }

        public static List<T> NextUniqueSubset<T>(this Random r, ISet<T> set)
        {
            int count = r.Next(1, set.Count + 1);

            List<T> list = new List<T>(set);
            r.NextShuffle(list);

            return list.GetRange(0, count);
        }
    }
}
