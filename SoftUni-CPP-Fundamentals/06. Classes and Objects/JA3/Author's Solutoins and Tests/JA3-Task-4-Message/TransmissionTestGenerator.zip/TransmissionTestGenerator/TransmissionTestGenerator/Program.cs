﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransmissionTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 10, 1, 5, 3, 0);
            GenerateTest("test.002", 20, 1, 10, 40, 0);
            GenerateTest("test.003", 30, 10, 20, 40, 0);
            GenerateTest("test.004", 40, 1, 10, 200, 100);
            GenerateTest("test.005", 50, 10, 20, 200, 200);
            GenerateTest("test.006", 10, 1, 5, 300, 110);
            GenerateTest("test.007", 20, 1, 10, 400, 110);
            GenerateTest("test.008", 30, 10, 20, 400, 10);
            GenerateTest("test.009", 40, 1, 10, 300, 200);
            GenerateTest("test.010", 50, 10, 20, 400, 200);
        }

        static void GenerateTest(string testName, int uniqueWordsCount, int minWordOccurrences, int maxWordOccurrences, int validQueriesCount, int nonValidQueriesCount)
        {
            StringBuilder transmissionBuilder = new StringBuilder();

            HashSet<string> uniqueWordsSet = new HashSet<string>();
            while (uniqueWordsSet.Count < uniqueWordsCount)
            {
                uniqueWordsSet.Add(GetRandomWord());
            }

            List<string> words = new List<string>();
            HashSet<int> occurrencesSet = new HashSet<int>();

            Dictionary<int, List<string>> groups = new Dictionary<int, List<string>>();

            foreach (var word in uniqueWordsSet)
            {
                int occurrenceCount = rand.Next(minWordOccurrences, maxWordOccurrences + 1);
                occurrencesSet.Add(occurrenceCount);

                if (!groups.ContainsKey(occurrenceCount))
                {
                    groups.Add(occurrenceCount, new List<string>());
                }
                groups[occurrenceCount].Add(word);

                for (int i = 0; i < occurrenceCount; i++)
                {
                    words.Add(word);
                }
            }

            Shuffle(words);

            List<int> occurrences = new List<int>(occurrencesSet);
            List<KeyValuePair<string, string>> queryResultPairs = new List<KeyValuePair<string, string>>();

            for (int i = 0; i < validQueriesCount; i++)
            {
                Console.CursorLeft = 0;
                Console.Write("valid: " + i / (double)validQueriesCount);
                int occurrenceCount = occurrences[rand.Next(0, occurrences.Count)];

                //List<string> group = FindWordsWithOccurrence(occurrenceCount, words);
                List<string> group = groups[occurrenceCount];
                group.Sort();
                int index = rand.Next(0, group.Count);

                queryResultPairs.Add(new KeyValuePair<string, string>(occurrenceCount + " " + index, group[index]));
            }

            for (int i = 0; i < nonValidQueriesCount; i++)
            {
                Console.CursorLeft = 0;
                Console.Write("valid: " + i / (double)validQueriesCount);
                int occurrenceCount = 1;
                while (occurrencesSet.Contains(occurrenceCount))
                {
                    occurrenceCount = rand.Next(minWordOccurrences, maxWordOccurrences + (maxWordOccurrences - minWordOccurrences));
                }

                queryResultPairs.Add(new KeyValuePair<string, string>(occurrenceCount + " " + rand.Next(minWordOccurrences, maxWordOccurrences + 1), "."));
            }

            Shuffle(queryResultPairs);

            StringBuilder inputBuilder = new StringBuilder();
            inputBuilder.AppendLine(String.Join(" ", words) + " .");
            inputBuilder.AppendLine(queryResultPairs.Count + "");

            StringBuilder outputBuilder = new StringBuilder();

            foreach (var queryResult in queryResultPairs)
            {
                inputBuilder.AppendLine(queryResult.Key);
                outputBuilder.AppendLine(queryResult.Value);
            }

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", outputBuilder.ToString());
        }

        static List<string> FindWordsWithOccurrence(int occurrence, List<string> words)
        {
            return words.FindAll((currW) => words.Count((w) => currW == w) == occurrence);
        }

        static string wordCharacters = null;

        static string GetRandomWord()
        {
            if (wordCharacters == null)
            {
                StringBuilder characters = new StringBuilder();
                for (char c = 'a'; c <= 'z'; c++)
                {
                    characters.Append(c);
                }

                for (char c = '0'; c <= '9'; c++)
                {
                    characters.Append(c);
                }

                wordCharacters = characters.ToString();
            }

            int length = rand.Next(1, 20);
            StringBuilder word = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                word.Append(wordCharacters[rand.Next(0, wordCharacters.Length)]);
            }

            return word.ToString();
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }
}
