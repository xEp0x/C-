﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamsTestGenerator
{
    class Program
    {
        static Random rand = new Random();

        static void Main(string[] args)
        {
            GenerateTest("test.001", 7, 12, 1, 5, 20);
            GenerateTest("test.002", 7, 12, 1, 5, 20);
            GenerateTest("test.003", 70, 30, 1, 10, 100);
            GenerateTest("test.004", 70, 30, 1, 10, 100);
            GenerateTest("test.005", 1, 5, 1, 1, 27);
            GenerateTest("test.006", 1, 5, 1, 1, 27);
            GenerateTest("test.007", 5, 1, 5, 5, 76);
            GenerateTest("test.008", 5, 1, 5, 5, 76);
            GenerateTest("test.009", 30, 70, 1, 10, 80);
            GenerateTest("test.010", 30, 70, 1, 10, 80);
        }

        static void GenerateTest(string testName, int playersCount, int teamsCount, int minPlayersPerTeam, int maxPlayersPerTeam, int gamesCount)
        {
            HashSet<string> players = new HashSet<string>();
            while (players.Count < playersCount)
            {
                players.Add(GetRandomWord());
            }

            List<HashSet<string>> teams = new List<HashSet<string>>();

            while (teams.Count < teamsCount)
            {
                teams.Add(new HashSet<string>());
            }

            SortedDictionary<string, int> winsByPlayer = new SortedDictionary<string, int>();
            foreach (string player in players)
            {
                rand.Next(teams).Add(player);
                winsByPlayer.Add(player, 0);
            }

            List<string> playersList = new List<string>(players);

            Dictionary<string, HashSet<string>> teamsByName = new Dictionary<string, HashSet<string>>();
            List<string> teamNames = new List<string>();

            foreach (HashSet<string> team in teams)
            {
                int teamPlayersCount = rand.Next(minPlayersPerTeam, maxPlayersPerTeam + 1);
                while (team.Count < teamPlayersCount)
                {
                    string teammate = rand.Next(playersList);
                    team.Add(teammate);
                    if (!winsByPlayer.ContainsKey(teammate))
                    {
                        winsByPlayer.Add(teammate, 0);
                    }
                }

                string teamName = GetRandomWord();
                while (teamsByName.ContainsKey(teamName))
                {
                    teamName = GetRandomWord();
                }

                teamsByName.Add(teamName, team);
                teamNames.Add(teamName);
            }

            List<string> winners = new List<string>();
            while (winners.Count < gamesCount)
            {
                string teamName = rand.Next(teamNames);
                foreach (var teammate in teamsByName[teamName])
                {
                    winsByPlayer[teammate]++;
                }

                winners.Add(teamName);
            }

            List<int> winsSortedByPlayer = new List<int>();
            foreach (var entry in winsByPlayer)
            {
                winsSortedByPlayer.Add(entry.Value);
            }

            StringBuilder inputBuilder = new StringBuilder();
            inputBuilder.AppendLine(teamsByName.Count + "");
            foreach (var entry in teamsByName)
            {
                inputBuilder.Append(entry.Key + " ");
                inputBuilder.Append(entry.Value.Count + " ");
                inputBuilder.Append(string.Join(" ", entry.Value));
                inputBuilder.AppendLine();
            }

            inputBuilder.AppendLine(winners.Count + "");
            inputBuilder.AppendLine(string.Join(System.Environment.NewLine, winners));

            System.IO.File.WriteAllText(testName + ".in.txt", inputBuilder.ToString());
            System.IO.File.WriteAllText(testName + ".out.txt", string.Join(" ", winsSortedByPlayer));

        }

        static string wordCharacters = null;

        static string GetRandomWord(int length = 0)
        {
            if (wordCharacters == null)
            {
                StringBuilder characters = new StringBuilder();
                for (char c = 'a'; c <= 'z'; c++)
                {
                    characters.Append(c);
                }

                wordCharacters = characters.ToString();
            }

            length = length == 0 ? rand.Next(1, 10 + 1) : length;
            StringBuilder word = new StringBuilder();
            for (int i = 0; i < length; i++)
            {
                word.Append(wordCharacters[rand.Next(0, wordCharacters.Length)]);
            }

            return word.ToString();
        }

        static void Shuffle<T>(List<T> list)
        {
            for (int repeats = 0; repeats < 10; repeats++)
            {
                for (int i = 0; i < list.Count; i++)
                {
                    int otherInd = rand.Next(0, list.Count);
                    var swap = list[i];
                    list[i] = list[otherInd];
                    list[otherInd] = swap;
                }
            }
        }
    }

    static class RandomExtensions
    {
        public static T Next<T>(this Random thiz, IList<T> c)
        {
            return c[thiz.Next(0, c.Count)];
        }
    }
}
